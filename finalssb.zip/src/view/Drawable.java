package view;

import java.awt.*;

public interface Drawable {
    void draw(Graphics g);
}
