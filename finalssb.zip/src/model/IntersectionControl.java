package model;

public interface IntersectionControl {
    int intersects();
}
