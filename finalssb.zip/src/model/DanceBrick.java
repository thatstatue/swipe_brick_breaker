package model;

import java.awt.*;

public class DanceBrick extends Brick{
    public DanceBrick(int x, int y, int weight) {
        super(x, y, weight);
        color = Color.MAGENTA;
    }
}
